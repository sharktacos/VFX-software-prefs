#
#
#  Copyright (c) 2014, 2015, 2016, 2017 Psyop Media Company, LLC
#  See license.txt
#
#

import cryptomatte_utilities
cryptomatte_utilities.setup_cryptomatte()

