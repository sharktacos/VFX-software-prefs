<h2>Installation</h2>

Each folder here goes in its parallel folder in your Substance user shelf. On Windows:<p>

C:\Users\YOUR USERNAME HERE\Documents\Allegorithmic\Substance Painter\shelf\

<h2>Usage</h2>
Watch a <a href="https://vimeo.com/469364354">video walkthrough</a> of the tools and how they are used to optimze your workflow .

