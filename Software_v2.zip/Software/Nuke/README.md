<h1>Installation</h1>
Place contents in the .nuke folder of your $HOME directory (if at the school lab that's your Z drive). 
<h2>Windows</h2>
  You can find the $HOME folder by typing %HOME% or %USERPROFILE% in an Explorer Browser.
<h2>MacOS</h2>
  In the finder menu select <b>go>home</b>. This folder is hidden by default. To show it Press CMD+Shift+Period in the Finder.

