<h2>Project template</h2>
Zip file containing Maya project folders for an animation studio pipeline.
<h2>Turntable Setup</h2>
Maya files for look development turntable setup.
<h2>scripts</h2>
Python and Mel scripts. Place these in your Maya scripts folder.
<h2>Maya shelf</h2>
A Maya shelf containing the above scripts and some other goodies. This goes in your Maya prefs folder. 
